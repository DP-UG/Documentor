
function unDPformula() {
   elem=document.getElementsByTagName("pre") ;
   var c ;
   for(var i=0,e; e=elem[i]; i++) {
      c=e.innerHTML ;
      if (c.length>0) {
         //alert(dpSteFormula(c)) ;
         e.innerHTML = dpSteFormula(c);
      }
   }
   return void(0);
}

// function showhide() {
// 	elem=document.getElementsByTagName("pre") ;
// 	for (var i=0;i < elem.length; i++) {
// 		if ( i < 5) alert(elem[i].id) ;
// 		elem[i].style.display = (elem[i].style.display=="none" ? "block" : "none")
// 	}
// }

var isHidden = new Array() ;
isHidden["formula"] = true ;
isHidden["indexes"] = false ;
isHidden["panellinks"] = false ;
isHidden["datalinks"] = false ;
function showhide(className) {
 	var e = getElementsByClass(className) ;
 	for (var i=0; i < e.length; i++) {
 		e[i].style.display = (isHidden[className] ? "block" : "none") ;
	};
	isHidden[className] = !isHidden[className] ;
	return void(0) ;
};
function toggle(obj) {
	var e = document.getElementById(obj);
	e.style.display = (e.style.display=="none" ? "block" : "none") ;
	return void(0) ;
}
function show(className, chkbox) {
 	var e = getElementsByClass(className) ;
 	for (var i=0; i < e.length; i++) {
 		e[i].style.display = (chkbox.checked ? "block" : "none") ;
	};
};

function getElementsByClass(searchClass,node,tag) {
	var classElements = new Array();
	if ( node == null )
		node = document;
	if ( tag == null )
		tag = '*';
	var els = node.getElementsByTagName(tag);
	var elsLen = els.length;
	var pattern = new RegExp('(^|\\\\s)'+searchClass+'(\\\\s|$)');
	for (i = 0, j = 0; i < elsLen; i++) {
		if ( pattern.test(els[i].className) ) {
			classElements[j] = els[i];
			j++;
		}
	}
	return classElements;
}

function isIE() {
	var re=/MSIE/ ;
	var str = navigator.userAgent ;
	return re.test(str) ;
}
function dpSteFormula(str) {

   var re=/~? +CR *\r?\n/g ;
   str = str.replace(re,"\n") ;
   re = /^ *\r?\n/mg ;
   str = str.replace(re,"") ;
   re = /^ *~/gm  ;
   str = str.replace(re,"") ;
   re = /~? *FIELD=(\w+) *~?/g ;
   str = str.replace(re," $1 ") ;
   re=/^ (\w)/mg ;
   str = str.replace(re,"$1") ;
   re=/~ *$/gm ;
   str = str.replace(re,"") ;
   re=/ *\r?\n *$/ ;
   str = str.replace(re,"") ;
   //re = /^ *\r?\n/ ;
   //str = str.replace(re,"") ;
   //re=/\bendif~/ig ;
   //str = str.replace(re,"ENDIF") ;
   str = ToolTipIt(str) ;
   if (isIE()) {
   	re=/\n/g ;
	str = str.replace(re,"<br />") ;
   }
   return str ;
}
function ToolTipIt(str) {
	// simple field references eg PxFy
	var re=/(\bP\d{1,3}F\d{1,3}\b)/g;
	str = str.replace(re,"<a class=\"tooltips\" href=\"Javascript:void(0)\" onmouseover=\"Tip(FieldTipText('$1'))\" onmouseout=\"UnTip()\">$1</a>") ;
	re=/(\bP\d{1,3}F\d{1,3})(P\d{1,3}F\d{1,3}\b)/g;
	str = str.replace(re,"<a class=\"tooltips\" href=\"Javascript:void(0)\" onmouseover=\"Tip(FieldTipText('$2','$1'))\" onmouseout=\"UnTip()\">$1$2</a>")
return str ;
}
function FieldTipText(field, link) {
	var out  = "<table border='0'>" ;
		out += "<tr><td>Field:</td><td>" + field + "</td></tr>" ;
    	out += "<tr><td>Description:</td><td>" + (afield[field].description ? afield[field].description : " (no description") + (link ? " in Panel " + afield[field].panel : "") + "</td></tr>";
		out += "<tr><td>Format:</td><td>" + afield[field].format + "</td></tr>";
		out += (link ? "<tr><td>via:</td><td>" + afield[link].linktype + " through " + link + " (" + afield[link].description + ")</td></tr>" : "") ;
		out += "</table>" ;
	return out ;
}
function FieldNoteTipText(field) {
		 return afield[field].note ;
}
function PanelTipText(field) {
	return aPanel[field];
}